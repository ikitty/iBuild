(function () {
    var msg = navigator.userAgent
    var el = document.getElementById('msg')
    el && (el.innerHTML = msg )
})();
